var app = angular.module('myApp', ['ngCookies']);

app.controller('myController', function ($scope, $cookies) {
  // Retrieve values from cookies and assign them to scope variables
  $scope.firstName = $cookies.get('firstName');
  $scope.lastName = $cookies.get('lastName');
  $scope.email = $cookies.get('email');
  $scope.password = $cookies.get('password');
  $scope.address1 = $cookies.get('address1');
  $scope.city = $cookies.get('city');
  $scope.State = $cookies.get('State');
});


